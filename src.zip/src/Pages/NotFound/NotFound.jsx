import React from 'react';

import styles from './NotFound.module.scss';

function NotFound() {
   
   return (
      <p>NotFoundPage</p>
   )
}

export default NotFound;